module.exports = {
    render: require('./render'),
    toc: require('./toc'),
    title: require('./title'),
};
