const Slugger = require('../../helpers/Slugger');

/**
 * Global instance for marked
 */
const slugger = new Slugger();
module.exports = slugger;
