/* embedded layout names */
module.exports = [
    'default',
    'github',
    'remarkjs'
];
