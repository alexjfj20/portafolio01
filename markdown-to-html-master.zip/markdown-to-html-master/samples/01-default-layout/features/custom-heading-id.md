# Custom heading id

[[toc]]

## Long title with first id {#first-id}

`#first-id` is generated on this title using the following syntax `## Long title with first id {#first-id}`

## Syntax may differ

Note that some other may support another syntax like `## [Long title with first id](#first-id)`.

## Let's go!

It's time to test some special chars...

[Back to home...](../)
