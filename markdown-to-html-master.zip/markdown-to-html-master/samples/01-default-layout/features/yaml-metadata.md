---
title: Custom title from YAML metadata
lang: en
---

# Using YAML metadata

This page rely on YAML metadata to control "title" and "lang" in HTML page :

```yaml
---
title: Custom title from YAML metadata
lang: en
---
```

[Back to home...](../)

