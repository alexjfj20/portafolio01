# Math formula with mathjax

$$
x = {-b \pm \sqrt{b^2-4ac} \over 2a}.
$$

[Back to home...](../)
