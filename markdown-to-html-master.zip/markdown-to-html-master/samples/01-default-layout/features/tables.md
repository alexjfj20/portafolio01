# Tables

Note that you can generate markdown tables with [www.tablesgenerator.com](https://www.tablesgenerator.com/markdown_tables)

## Basic table

| Syntax      | Description |
| ----------- | ----------- |
| Header      | Title       |
| Paragraph   | Text        |

## Table with alignment

| Syntax    | Description |   Test Text |
|:----------|:-----------:|------------:|
| Header    |    Title    | Here's this |
| Paragraph |    Text     |    And more |

[Back to home...](../)
