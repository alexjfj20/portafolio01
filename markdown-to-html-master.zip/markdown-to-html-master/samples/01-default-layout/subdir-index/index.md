# subdir-index

Testing a subdirectory with an index.md file.
